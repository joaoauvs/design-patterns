/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author puc
 */
public class Chimpanzee implements Macaco {

    @Override
    public void comer() {
        System.out.print("Chimpanzee Come");
    }

    @Override
    public void dormir() {
        System.out.print("Chimpanzee Dorme");
    }

    @Override
    public void pular() {
        System.out.print("Chimpanzee Pula");
    }

    void matarSede() {
        System.out.print("Chimpanzee Bebe àgua");
    }

    void macacoDoLar() {
        System.out.print("Chimpanzee Adestrado");
    }
    
}
