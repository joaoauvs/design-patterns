/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// Cliente humano que vai utilizar atribuições da classe chimpanzee através do adapter.
package adapter;

/**
 *
 * @author puc
 */
public class ClienteMacaco {
    public static void main( String[] args ){
        Homem humano = new Homem();
        Chimpanzee macaco = new Chimpanzee();
        
        HumanoAdapter humanoAdapter = new HumanoAdapter(humano);
        Macaco[] macacos = {macaco, humanoAdapter};
        
        for(Macaco m : macacos){
            m.comer();
            System.out.println();
            m.dormir();
            System.out.println();
            m.pular();
            System.out.println();
        }
    }
}
