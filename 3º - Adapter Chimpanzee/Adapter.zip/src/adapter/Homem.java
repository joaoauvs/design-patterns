/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;
/**
 *
 * @author puc
 */
public class Homem implements Humano {

    @Override
    public void comer() {
        System.out.print("Homem Come");
    }

    
    @Override
    public void beber() {
        System.out.print("Homem Bebe");
    }

    @Override
    public void vestir() {
        System.out.print("Homem se Vesti");
    }

    @Override
    public void Cansar() {
        System.out.print("Homem Cansa ao Pular ");
    }
    
}
