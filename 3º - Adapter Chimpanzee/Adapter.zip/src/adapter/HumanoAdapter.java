/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author Administrador
 */
public class HumanoAdapter implements Macaco {
    private Humano humano;
    
    public HumanoAdapter(Humano humano){
        this.humano = humano;
    }

    @Override
    public void comer() {
        humano.beber();
    }

    @Override
    public void dormir() {
        humano.comer();
    }

    @Override
    public void pular() {
        humano.Cansar();
    }
    
}
