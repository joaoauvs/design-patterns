package Interface;

public interface Produtos {
    public String getNome();
    public String getDescricao();
    public String  getPreco();
}